import { Injectable } from "@angular/core";

@Injectable()
export class Globals {
   url = 'http://localhost:3000/';
  // url = "https://art-kem-arafat.herokuapp.com/";
  printobj;
}
