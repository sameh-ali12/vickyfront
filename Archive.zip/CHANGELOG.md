## [1.1.0] - 2020-03-10
### Updates
- update to Angular 9
- update all dependencies to match Angular 9 version

## [1.0.0] 2019-07-19
### Initial Release
